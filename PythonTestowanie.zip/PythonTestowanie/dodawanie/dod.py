def dodawanie(x, y):
    return x + y