import unittest
from dodawanie import dod

class TestCalc(unittest.TestCase):
    
    def test_dodawanie(self):
        self.assertEqual(dod.dodawanie(3, 6), 9)
        self.assertEqual(dod.dodawanie(3, 3), 6)
		
if __name__ == '__main__':  

    unittest.main()