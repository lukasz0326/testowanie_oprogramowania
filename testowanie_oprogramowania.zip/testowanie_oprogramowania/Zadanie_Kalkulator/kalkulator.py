import math

def add(num1, num2):
    return num1 + num2

def subtract(num1, num2):
    return num1 - num2

def multiplication(num1, num2):
    return num1 * num2

def division(num1, num2):
    return num1 / num2
    if(num  == 0):
        print ("Nie można dzielić przez zero")


def exponentiation(num1):
    return num1**2

def squareRoot(num1):
    return math.sqrt(num1)

def percent(num1, num2):
    return num1 % num2

import unittest
import kalkulator

class testKalkulator(unittest.TestCase):

    def testAdd(self):
        self.assertEqual(kalkulator.add(10, 10), 20)

    def testSubtract(self):
        self.assertEqual(kalkulator.subtract(10, 5), 5)

    def testMultiplication(self):
        self.assertEqual(kalkulator.multiplication(3, 3), 9)

    def testDivision(self):
        self.assertEqual(kalkulator.division(3, 3), 1)
        self.assertRaises(ZeroDivisionError, kalkulator.division, 2, 0)

    def testExponentiation(self):
        self.assertEqual(kalkulator.exponentiation(3), 9)

    def testSquareRoot(self):
        self.assertEqual(kalkulator.squareRoot(4), 2)

    def testPercent(self):
        self.assertEqual(kalkulator.percent(5, 4), 1)
        self.assertRaises(ZeroDivisionError, kalkulator.percent, 4, 0)

if __name__ == '__main__':
    unittest.main()
