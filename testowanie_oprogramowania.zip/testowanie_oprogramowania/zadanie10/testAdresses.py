import unittest
import adress

class AdressTestCase(unittest.TestCase):

    def setUp(self):
        self.adresses = ['żytnia', '72 300']
        self.dash = True
        self.tab = []

    def test_adsress_in_list(self):

        for x in self.adresses:
            if '-' in x:
                self.dash = False
                delete_dash = x.replace('-', ' ')
                self.tab.append(delete_dash)
            else:
                self.dash = False
                self.tab.append(x)


        print(self.tab)
        self.assertEqual(self.tab, ['żytnia', '72 300 '])
        self.assertFalse(self.dash)


if __name__ == '__main__':
    unittest.main()