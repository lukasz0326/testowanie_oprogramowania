def format_adresses(adresses):
    return adresses