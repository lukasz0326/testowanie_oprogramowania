class FootBallClub:

    def __init__(self, clubName, country, trainer=None):
        self.clubName = clubName
        self.country = country
        self.trainer = trainer

    def checkTrainer(self):
        if(self.trainer != None):
            return True
        else:
            return False

x = FootBallClub("Japkowo", "Anglia", "Marcin Prokop")

print(x.checkTrainer())