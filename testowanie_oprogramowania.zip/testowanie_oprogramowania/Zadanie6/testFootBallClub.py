import unittest
from Zadanie6.FootBallClub import FootBallClub

class TestClub(unittest.TestCase):

    def setUp(self):
        self.footBallClub = FootBallClub("Japkowo", "Anglia")

    def test_check(self):
        result = self.footBallClub.checkTrainer()
        self.assertEqual(result, False)


if __name__ == '__main__':
    unittest.main()
