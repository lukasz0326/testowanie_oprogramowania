class FootBall:
    def __init__(self, clubname):
        self.clubname = clubname

    def createFile(self, filename):
        x = open(filename + ".txt", "a+")
        x.write(self.clubname + "\n")
        x.close()