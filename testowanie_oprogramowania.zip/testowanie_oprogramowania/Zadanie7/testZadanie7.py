import os
import unittest
from FootBall import FootBall

class TestFootBallClub(unittest.TestCase):
    filename = "kluby"

    def setUp(self):
        self.footBallClub1 = FootBall("Manchester City")
        self.footBallClub1.createFile(self.filename)
        self.footBallClub2= FootBall("Bayern")
        self.footBallClub2.createFile(self.filename)

    def tearDown(self):
        os.remove(self.filename + ".txt")

    def test_createFile(self):
        f = open(self.filename + ".txt")
        tab = []
        if(f.mode == 'r'):
            result = f.readlines()
            for r in result:
                tab.append(r.strip())
        f.close()
        self.assertEqual(tab[0], "Manchester City")
        self.assertEqual(tab[1], "Bayern")



if __name__ == '__main__':
    unittest.main()