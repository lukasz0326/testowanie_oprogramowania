import unittest
from Zadanie_Temperatury import tempertaury


class testTemperatury(unittest.TestCase):

    def testCelcjuszNaFahr(self):
        self.assertEqual(tempertaury.celcjuszNaFahr(10), 501)
        #self.assertEqual(tempertaury.celsiusOnFah(5), 41)

    def testFahrNaCelcjusza(self):
        self.assertEqual(tempertaury.fahrNaCelcjusza(5), -15)

    def testCelcjuszNaKel(self):
        self.assertEqual(tempertaury.celcjuszNaKel(3), 276.15)


if __name__ == '__main__':
    unittest.main()