def celcjuszNaFahr(cel):
    return (cel * 9/5) + 32

def fahrNaCelcjusza(fah):
    return (fah - 32) * 5/9

def celcjuszNaKel(cel):
    return (cel + 273.15)