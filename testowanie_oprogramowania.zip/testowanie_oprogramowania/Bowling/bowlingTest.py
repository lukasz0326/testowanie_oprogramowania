import unittest
from bowling import Bowling
class TEST_BOWLING(unittest.TestCase):

    def setUp(self):
        self.bowling = Bowling()


    def test_strike(self):
        self.bowling.bound(10)
        self.bowling.bound(3)
        self.bowling.bound(6)
        self._roll_many(0, 16)
        self.assertEqual(28, self.bowling.score())

    def test_spare(self):
        self._roll_spare()
        self.bowling.bound(3)
        self._roll_many(0, 17)
        self.assertEqual(16, self.bowling.score())

    def _roll_many(self, pins, num):
        for i in range(num):
            self.bowling.bound(pins)

    def _roll_spare(self):
        self.bowling.bound(5)