class Bowling(object):

    def __init__(self):
        self.bounds = []

    def bound(self, pins):
        self.bounds.append(pins)

    def score(self):
        score = 0
        bound_index = 0
        for frame in range(10):
            if self._is_strike(bound_index):
                score += 10 + self.bounds[bound_index+1] + self.bounds[bound_index+2]
                bound_index += 1
            elif self._is_spare(bound_index):
                score += 10 + self.bounds[bound_index+2]
                bound_index += 2
            else:
                score += self.bounds[bound_index] + self.bounds[bound_index+1]
                bound_index += 2
        return score



    def _is_strike(self, bound_index):
        return self.bounds[bound_index] == 10

    def _is_spare(self, bound_index):
        return self.bounds[bound_index] + self.bounds[bound_index+1] == 10