class Employee:
    def __init__(self, name, surname, salary):
        self.name = name
        self.surname = surname
        self.salary = salary * 2


    def email(self):
        return self.name + "." + self.surname + "@testemail.com"

    def fullName(self):
        return self.name + " " + self.surname

    def raiseSalary(self):
        return self.salary

x = Employee("X","Y",3000)
print(x.raiseSalary())





