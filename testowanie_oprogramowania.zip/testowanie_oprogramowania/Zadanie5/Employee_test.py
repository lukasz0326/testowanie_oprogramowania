import unittest
from Zadanie5.Employee import Employee

class TestEmployee(unittest.TestCase):

    def setUp(self):
        self.employee = Employee("Marcin", "Prokop", 7000)

    def test_email(self):
        result = self.employee.email()
        self.assertEqual(result, "Marcin.Prokop@testemail.com")

    def test_fullName(self):
        result = self.employee.fullName()
        self.assertEqual(result, "Marcin Prokop")

    def test_raiseSalary(self):
        result = self.employee.raiseSalary()
        self.assertEqual(result, 14000)

if __name__ == '__main__':
    unittest.main()