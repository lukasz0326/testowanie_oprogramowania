import unittest
import Portfel


def poczatkowaWartoscPorfela(self):
    self.portfelPierwszy.SrodkiWPortfelu = 150
    print("Nasze środki w porfelu wynoszą: " + str(self.portfelPierwszy.SrodkiWPortfelu))

def dodanieSrodkowDoPorfela(self):
    self.portfelPierwszy.SrodkiWPortfelu += 500
    print("Nasze środki w portfelu wynoszą: " + str(self.portfelPierwszy.SrodkiWPortfelu))

def wydanieSrodkowZPortfela(self):
    self.portfelPierwszy.SrodkiWPortfelu -= 100
    print("Nasze środki w porfelu wynoszą: " + str(self.portfelPierwszy.SrodkiWPortfelu))

class TesowaniePortfela(unittest.TestCase):
    def setUp(self):
        self.portfelPierwszy = Portfel.Portfel("Mariusz","Pudzianowski")
        return self.portfelPierwszy
    def testowaniePortfela(self):
        print('1. Wartość domyślna portfela  ' + str(self.portfelPierwszy.SrodkiWPortfelu))
        self.assertEqual(self.portfelPierwszy.SrodkiWPortfelu, 0)

        print("2. Ustawienie początkowej wartości portfela ")
        poczatkowaWartoscPorfela(self)
        self.assertEqual(self.portfelPierwszy.SrodkiWPortfelu,150)

        print("3. Dodawanie środków do portfela ")
        dodanieSrodkowDoPorfela(self)
        self.assertEqual(self.portfelPierwszy.SrodkiWPortfelu,650)

        print("4. Wydanie środków z portfela")
        wydanieSrodkowZPortfela(self)
        self.assertEqual(self.portfelPierwszy.SrodkiWPortfelu,550)

if __name__== '__main__':

    unittest.main()


