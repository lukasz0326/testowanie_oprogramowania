class Portfel:
    def __init__(self, Imie, Nazwisko):
        self.Imie = Imie
        self.Nazwisko = Nazwisko
        self.SrodkiWPortfelu = 0